package com.example.bmi_calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText edweg,edhei;
        TextView tres,tenter;
        Button btnresult,btnreset;

        edweg=(EditText) findViewById(R.id.edweg);
        edhei=(EditText) findViewById(R.id.edhei);

        tres=(TextView) findViewById(R.id.tres);
        tenter=(TextView) findViewById(R.id.tenter);

        btnresult=(Button) findViewById(R.id.btnresult);
        btnreset=(Button) findViewById(R.id.btnreset);

        btnresult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strweg=edweg.getText().toString();
                String strhei = edhei.getText().toString();

                if (strweg.equals("")){
                    edweg.setError("PLease Enter your Weight");
                    edweg.requestFocus();
                    return;
                }

                if (strhei.equals("")){
                    edhei.setError("PLease Enter your Height");
                    edhei.requestFocus();
                    return;
                }

                float weight= Float.parseFloat(strweg);
                float height= Float.parseFloat(strhei)/100;

                float bmiValue=BMICalculate(weight,height);

                tenter.setText(interpreteBMI(bmiValue));

                tres.setText("BMI= "+bmiValue);

            }
        });

        btnreset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edhei.setText("");
                edweg.setText("");
                tenter.setText("");
                tres.setText("");
            }
        });


    }
    public float BMICalculate(float weight,float height){
        return weight/(height*height);

    }
    public String interpreteBMI(float bmiValue){
        if(bmiValue < 16){
            return "Servely Underweight";
        }
        else if (bmiValue <18.5){
            return "Unterweight";

        }
        else if (bmiValue < 25) {
            return "Normal";

        }
        else if (bmiValue < 30){
            return "Overweight";
        }
        else
            return "obese";

    }
}